package ch.zli.m223;

public class CalcService {
    
    public Number add(double a, double b) {

        return a+b;
    }
}
